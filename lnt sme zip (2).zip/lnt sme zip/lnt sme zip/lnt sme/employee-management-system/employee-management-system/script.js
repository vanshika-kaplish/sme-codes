/* PeopleDesk Employee Management System
   Demo data is stored in this browser with localStorage. No backend is required. */
const STORAGE_KEY = "peopledesk_employees_v1";
const ATTENDANCE_KEY = "peopledesk_attendance_v1";
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const seedEmployees = [
  {id:"EMP1001",name:"Aarav Sharma",department:"Engineering",role:"Frontend Developer",email:"aarav.sharma@example.com",salary:65000,status:"Active"},
  {id:"EMP1002",name:"Diya Patel",department:"Human Resources",role:"HR Executive",email:"diya.patel@example.com",salary:42000,status:"Active"},
  {id:"EMP1003",name:"Rohan Verma",department:"Finance",role:"Accountant",email:"rohan.verma@example.com",salary:48000,status:"Active"},
  {id:"EMP1004",name:"Ananya Singh",department:"Marketing",role:"Marketing Specialist",email:"ananya.singh@example.com",salary:52000,status:"Active"},
  {id:"EMP1005",name:"Vivaan Gupta",department:"Sales",role:"Sales Executive",email:"vivaan.gupta@example.com",salary:39000,status:"Active"},
  {id:"EMP1006",name:"Isha Mehta",department:"Design",role:"UI/UX Designer",email:"isha.mehta@example.com",salary:58000,status:"Active"},
  {id:"EMP1007",name:"Aditya Kumar",department:"Engineering",role:"Backend Developer",email:"aditya.kumar@example.com",salary:72000,status:"Active"},
  {id:"EMP1008",name:"Saanvi Joshi",department:"Operations",role:"Operations Coordinator",email:"saanvi.joshi@example.com",salary:41000,status:"Active"},
  {id:"EMP1009",name:"Arjun Reddy",department:"Customer Support",role:"Support Specialist",email:"arjun.reddy@example.com",salary:35000,status:"Active"},
  {id:"EMP1010",name:"Myra Nair",department:"Finance",role:"Financial Analyst",email:"myra.nair@example.com",salary:61000,status:"Active"},
  {id:"EMP1011",name:"Kabir Das",department:"Engineering",role:"QA Engineer",email:"kabir.das@example.com",salary:54000,status:"Active"},
  {id:"EMP1012",name:"Aadhya Rao",department:"Marketing",role:"Content Writer",email:"aadhya.rao@example.com",salary:38000,status:"Active"},
  {id:"EMP1013",name:"Reyansh Shah",department:"Sales",role:"Sales Manager",email:"reyansh.shah@example.com",salary:78000,status:"Active"},
  {id:"EMP1014",name:"Kiara Malhotra",department:"Human Resources",role:"Talent Acquisition",email:"kiara.malhotra@example.com",salary:46000,status:"On leave"},
  {id:"EMP1015",name:"Ishaan Kapoor",department:"Engineering",role:"DevOps Engineer",email:"ishaan.kapoor@example.com",salary:82000,status:"Active"},
  {id:"EMP1016",name:"Pari Mishra",department:"Design",role:"Graphic Designer",email:"pari.mishra@example.com",salary:44000,status:"Active"},
  {id:"EMP1017",name:"Atharv Jain",department:"Operations",role:"Logistics Officer",email:"atharv.jain@example.com",salary:40000,status:"Active"},
  {id:"EMP1018",name:"Navya Bansal",department:"Finance",role:"Payroll Executive",email:"navya.bansal@example.com",salary:45000,status:"Active"},
  {id:"EMP1019",name:"Krish Yadav",department:"Customer Support",role:"Customer Success Associate",email:"krish.yadav@example.com",salary:36000,status:"Active"},
  {id:"EMP1020",name:"Sara Khan",department:"Marketing",role:"Social Media Manager",email:"sara.khan@example.com",salary:57000,status:"Active"},
  {id:"EMP1021",name:"Dhruv Chawla",department:"Engineering",role:"Full Stack Developer",email:"dhruv.chawla@example.com",salary:76000,status:"Active"},
  {id:"EMP1022",name:"Prisha Sethi",department:"Sales",role:"Account Executive",email:"prisha.sethi@example.com",salary:43000,status:"Active"},
  {id:"EMP1023",name:"Veer Purohit",department:"Operations",role:"Operations Manager",email:"veer.purohit@example.com",salary:69000,status:"Active"},
  {id:"EMP1024",name:"Riya Thomas",department:"Human Resources",role:"HR Manager",email:"riya.thomas@example.com",salary:68000,status:"Active"},
  {id:"EMP1025",name:"Yash Agarwal",department:"Engineering",role:"IT Support Engineer",email:"yash.agarwal@example.com",salary:47000,status:"Active"}
];

function readJSON(key, fallback) {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
  catch (error) { return fallback; }
}
let employees = readJSON(STORAGE_KEY, null);
if (!Array.isArray(employees) || employees.length === 0) {
  employees = seedEmployees.map(employee => ({...employee}));
  saveEmployees();
}
let attendance = readJSON(ATTENDANCE_KEY, {});
let activeDate = todayISO();
let toastTimeout;

function saveEmployees() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(employees)); }
  catch (error) { showToast("Could not save data in this browser.", "error"); }
}
function saveAttendanceData() {
  try { localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(attendance)); }
  catch (error) { showToast("Could not save attendance in this browser.", "error"); }
}
function todayISO() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}-${String(now.getDate()).padStart(2,"0")}`;
}
function money(value) {
  return new Intl.NumberFormat("en-IN", {style:"currency",currency:"INR",maximumFractionDigits:0}).format(Number(value)||0);
}
function initials(name) {
  return String(name).trim().split(/\s+/).slice(0,2).map(part=>part[0]||"").join("").toUpperCase();
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
function statusClass(status) {
  return ({"Active":"status-active","On leave":"status-on-leave","Inactive":"status-inactive","Present":"status-present","Absent":"status-absent","Leave":"status-leave","Not marked":"status-unmarked"})[status] || "status-unmarked";
}
function employeeCell(employee) {
  return `<div class="employee-cell"><span class="employee-avatar">${escapeHTML(initials(employee.name))}</span><span><span class="employee-name">${escapeHTML(employee.name)}</span><span class="employee-sub">${escapeHTML(employee.email)}</span></span></div>`;
}
function showToast(message, type="success") {
  const toast = $("#toast");
  toast.textContent = message;
  toast.className = `toast ${type} show`;
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove("show"), 3000);
}
function getDayAttendance(date=activeDate) {
  if (!attendance[date]) attendance[date] = {};
  return attendance[date];
}
function getStatus(employee, date=activeDate) {
  return getDayAttendance(date)[employee.id] || "Not marked";
}
function renderDashboard() {
  const statuses = employees.map(employee => getStatus(employee));
  const present = statuses.filter(status=>status==="Present").length;
  const absent = statuses.filter(status=>status==="Absent").length;
  const leave = statuses.filter(status=>status==="Leave").length;
  const activePayroll = employees.reduce((sum,employee)=>sum+(Number(employee.salary)||0),0);
  $("#statEmployees").textContent = employees.length;
  $("#statPresent").textContent = present;
  $("#statAbsent").textContent = absent;
  $("#presentPercent").textContent = `${employees.length ? Math.round(present/employees.length*100) : 0}% of team`;
  $("#statPayroll").textContent = money(activePayroll);
  $("#legendPresent").textContent = present;
  $("#legendAbsent").textContent = absent;
  $("#legendLeave").textContent = leave;
  $("#donutPercent").textContent = `${employees.length ? Math.round(present/employees.length*100) : 0}%`;
  const total = employees.length || 1;
  const p = present/total*360, a = absent/total*360, l = leave/total*360;
  $("#attendanceDonut").style.background = `conic-gradient(#20b77d 0deg ${p}deg,#f0a33e ${p}deg ${p+a}deg,#9b8bf5 ${p+a}deg ${p+a+l}deg,#e9edf4 ${p+a+l}deg 360deg)`;
  renderDashboardRows($("#dashboardSearch").value);
}
function renderDashboardRows(query="") {
  const q = query.trim().toLowerCase();
  const matches = employees.filter(e => [e.name,e.id,e.role,e.department,e.email].some(v=>v.toLowerCase().includes(q))).slice(0,6);
  $("#dashboardEmployeeRows").innerHTML = matches.length ? matches.map(e=>`<tr><td>${employeeCell(e)}</td><td class="department-cell">${escapeHTML(e.department)}</td><td><span class="status-badge ${statusClass(e.status)}">${escapeHTML(e.status)}</span></td><td class="salary-cell">${money(e.salary)}</td></tr>`).join("") : `<tr><td colspan="4" class="empty-row">No employees found.</td></tr>`;
  $("#directoryCount").textContent = q ? `${matches.length} matching employees (up to 6 shown)` : `Showing ${Math.min(6,employees.length)} of ${employees.length} employees`;
}
function renderDepartmentFilter() {
  const select = $("#departmentFilter");
  const old = select.value;
  const departments = [...new Set(employees.map(e=>e.department))].sort();
  select.innerHTML = `<option value="">All departments</option>` + departments.map(dept=>`<option value="${escapeHTML(dept)}">${escapeHTML(dept)}</option>`).join("");
  if (departments.includes(old)) select.value = old;
}
function renderEmployees() {
  const q = $("#employeeSearch").value.trim().toLowerCase();
  const dept = $("#departmentFilter").value;
  const filtered = employees.filter(e=>(!dept||e.department===dept)&&[e.name,e.id,e.role,e.department,e.email].some(v=>v.toLowerCase().includes(q)));
  $("#employeeRows").innerHTML = filtered.length ? filtered.map(e=>`<tr><td>${employeeCell(e)}</td><td>${escapeHTML(e.id)}</td><td>${escapeHTML(e.department)}</td><td>${escapeHTML(e.role)}</td><td>${escapeHTML(e.email)}</td><td><span class="status-badge ${statusClass(e.status)}">${escapeHTML(e.status)}</span></td><td class="salary-cell">${money(e.salary)}</td><td><button class="action-button" data-delete="${escapeHTML(e.id)}">Delete</button></td></tr>`).join("") : `<tr><td colspan="8" class="empty-row">No employees match your search.</td></tr>`;
  $("#employeePageTotal").textContent = employees.length;
  $("#employeeCountPill").textContent = employees.length;
  $("#employeeTableCount").textContent = `Showing ${filtered.length} of ${employees.length} employees`;
  const departments = new Set(employees.map(e=>e.department)).size;
  $("#departmentTotal").textContent = departments;
  $("#averageSalary").textContent = money(employees.length ? employees.reduce((sum,e)=>sum+Number(e.salary||0),0)/employees.length : 0);
}
function renderAttendance() {
  const q = $("#attendanceSearch").value.trim().toLowerCase();
  const filtered = employees.filter(e=>[e.name,e.id,e.role,e.department,e.email].some(v=>v.toLowerCase().includes(q)));
  $("#attendanceDate").value = activeDate;
  $("#attendanceSubheading").textContent = `Attendance register for ${new Date(`${activeDate}T12:00:00`).toLocaleDateString("en-IN",{day:"numeric",month:"long",year:"numeric"})}.`;
  $("#attendanceRows").innerHTML = filtered.length ? filtered.map(e=>{
    const status = getStatus(e);
    const checkin = status==="Present" ? "09:00 AM" : status==="Absent"||status==="Leave" ? "—" : "Not recorded";
    return `<tr><td>${employeeCell(e)}</td><td>${escapeHTML(e.department)}</td><td class="checkin">${checkin}</td><td><select class="attendance-select" data-attendance="${escapeHTML(e.id)}" aria-label="Attendance for ${escapeHTML(e.name)}"><option ${status==="Not marked"?"selected":""} value="Not marked">Not marked</option><option ${status==="Present"?"selected":""} value="Present">Present</option><option ${status==="Absent"?"selected":""} value="Absent">Absent</option><option ${status==="Leave"?"selected":""} value="Leave">On leave</option></select></td></tr>`;
  }).join("") : `<tr><td colspan="4" class="empty-row">No employees match your search.</td></tr>`;
  updateAttendanceStats();
  $("#attendanceRowCount").textContent = `Showing ${filtered.length} of ${employees.length} employees`;
}
function updateAttendanceStats() {
  const statuses = employees.map(e=>getStatus(e));
  const present = statuses.filter(s=>s==="Present").length;
  const absent = statuses.filter(s=>s==="Absent").length;
  const leave = statuses.filter(s=>s==="Leave").length;
  const unmarked = statuses.filter(s=>s==="Not marked").length;
  $("#attendancePresent").textContent=present;
  $("#attendanceAbsent").textContent=absent;
  $("#attendanceLeave").textContent=leave;
  $("#attendanceUnmarked").textContent=unmarked;
}
function renderSalary() {
  const q = $("#salarySearch").value.trim().toLowerCase();
  const filtered = employees.filter(e=>[e.name,e.id,e.role,e.department,e.email].some(v=>v.toLowerCase().includes(q)));
  $("#salaryRows").innerHTML = filtered.length ? filtered.map(e=>`<tr><td>${employeeCell(e)}</td><td>${escapeHTML(e.id)}</td><td>${escapeHTML(e.department)}</td><td>${escapeHTML(e.role)}</td><td><input class="salary-input" type="number" min="0" max="100000000" step="100" value="${Number(e.salary)||0}" data-salary="${escapeHTML(e.id)}" aria-label="Monthly salary for ${escapeHTML(e.name)}"></td><td class="salary-cell">${money((Number(e.salary)||0)*12)}</td><td><button class="save-salary" data-save-salary="${escapeHTML(e.id)}">Save</button></td></tr>`).join("") : `<tr><td colspan="7" class="empty-row">No employees match your search.</td></tr>`;
  const total = employees.reduce((sum,e)=>sum+(Number(e.salary)||0),0);
  $("#payrollTotal").textContent=money(total);
  $("#annualPayroll").textContent=money(total*12);
  $("#highestSalary").textContent=money(employees.length?Math.max(...employees.map(e=>Number(e.salary)||0)):0);
  $("#salaryEmployeeCount").textContent=employees.length;
  $("#salaryRowCount").textContent=`Showing ${filtered.length} of ${employees.length} salary records`;
}
function renderAll() {
  renderDepartmentFilter();
  renderDashboard();
  renderEmployees();
  renderAttendance();
  renderSalary();
}
function goToPage(page) {
  $$(".page-view").forEach(view=>view.classList.toggle("active",view.id===`page-${page}`));
  $$(".nav-item").forEach(button=>button.classList.toggle("active",button.dataset.page===page));
  const pageName = ({dashboard:"Dashboard",employees:"Employees",attendance:"Attendance",salary:"Salary Allotment"})[page] || "Dashboard";
  $("#breadcrumbPage").textContent=pageName;
  $("#sidebar").classList.remove("open");
  window.scrollTo({top:0,behavior:"smooth"});
}
function openModal() {
  $("#employeeForm").reset();
  $("#employeeModal").classList.add("open");
  setTimeout(()=>$('#employeeForm [name="name"]').focus(),60);
}
function closeModal() { $("#employeeModal").classList.remove("open"); }
function nextEmployeeId() {
  const used = new Set(employees.map(e=>e.id));
  let n=1001;
  while(used.has(`EMP${n}`)) n++;
  return `EMP${n}`;
}
function addEmployee(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const email = String(form.get("email")).trim().toLowerCase();
  if(employees.some(e=>e.email.toLowerCase()===email)) {
    showToast("An employee with this email already exists.", "error");
    return;
  }
  const employee = {
    id:nextEmployeeId(), name:String(form.get("name")).trim(),
    department:String(form.get("department")), role:String(form.get("role")).trim(),
    email, salary:Number(form.get("salary")), status:String(form.get("status")||"Active")
  };
  if(!employee.name||!employee.role||!employee.department||!Number.isFinite(employee.salary)||employee.salary<0) {
    showToast("Please check the employee details.", "error"); return;
  }
  employees.push(employee);
  saveEmployees(); closeModal(); renderAll(); showToast(`${employee.name} added successfully.`);
}
function deleteEmployee(id) {
  const employee=employees.find(e=>e.id===id);
  if(!employee) return;
  if(!confirm(`Delete ${employee.name} (${employee.id})? This will also remove their attendance records.`)) return;
  employees=employees.filter(e=>e.id!==id);
  Object.values(attendance).forEach(day=>{if(day) delete day[id];});
  saveEmployees(); saveAttendanceData(); renderAll(); showToast("Employee deleted successfully.");
}
function saveSalary(id) {
  const employee=employees.find(e=>e.id===id);
  const input=$(`[data-salary="${CSS.escape(id)}"]`);
  if(!employee||!input) return;
  const amount=Number(input.value);
  if(input.value.trim()===""||!Number.isFinite(amount)||amount<0||amount>100000000) {
    showToast("Enter a valid salary between ₹0 and ₹10 crore.", "error"); input.focus(); return;
  }
  employee.salary=amount; saveEmployees(); renderAll(); showToast(`Salary updated for ${employee.name}.`);
}
function exportPayroll() {
  const rows=[["Employee ID","Name","Department","Role","Email","Monthly Salary (INR)","Annual Estimate (INR)"],...employees.map(e=>[e.id,e.name,e.department,e.role,e.email,e.salary,e.salary*12])];
  const csv=rows.map(row=>row.map(value=>`"${String(value).replace(/"/g,'""')}"`).join(",")).join("\r\n");
  const blob=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8;"});
  const url=URL.createObjectURL(blob);
  const link=document.createElement("a"); link.href=url; link.download="peopledesk-payroll.csv";
  document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  showToast("Payroll CSV exported.");
}

document.addEventListener("click",event=>{
  const pageButton=event.target.closest("[data-page]");
  if(pageButton) goToPage(pageButton.dataset.page);
  const goButton=event.target.closest("[data-go]");
  if(goButton) goToPage(goButton.dataset.go);
  if(event.target.closest("[data-open-add]")) openModal();
  const deleteButton=event.target.closest("[data-delete]");
  if(deleteButton) deleteEmployee(deleteButton.dataset.delete);
  const saveSalaryButton=event.target.closest("[data-save-salary]");
  if(saveSalaryButton) saveSalary(saveSalaryButton.dataset.saveSalary);
});
$("#dashboardSearch").addEventListener("input",event=>renderDashboardRows(event.target.value));
$("#employeeSearch").addEventListener("input",renderEmployees);
$("#departmentFilter").addEventListener("change",renderEmployees);
$("#clearEmployeeSearch").addEventListener("click",()=>{$("#employeeSearch").value="";$("#departmentFilter").value="";renderEmployees();});
$("#attendanceSearch").addEventListener("input",renderAttendance);
$("#salarySearch").addEventListener("input",renderSalary);
$("#employeeForm").addEventListener("submit",addEmployee);
$("#closeModal").addEventListener("click",closeModal);
$("#cancelModal").addEventListener("click",closeModal);
$("#employeeModal").addEventListener("click",event=>{if(event.target===$("#employeeModal"))closeModal();});
document.addEventListener("keydown",event=>{
  if(event.key==="Escape") closeModal();
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==="k") {
    event.preventDefault();
    const active=$(".page-view.active");
    if(active.id==="page-dashboard") $("#dashboardSearch").focus();
    else if(active.id==="page-employees") $("#employeeSearch").focus();
    else if(active.id==="page-attendance") $("#attendanceSearch").focus();
    else $("#salarySearch").focus();
  }
});
$("#attendanceDate").addEventListener("change",event=>{
  if(!event.target.value) { event.target.value=activeDate; return; }
  activeDate=event.target.value; renderAttendance(); renderDashboard();
});
$("#attendanceRows").addEventListener("change",event=>{
  const select=event.target.closest("[data-attendance]");
  if(!select) return;
  getDayAttendance()[select.dataset.attendance]=select.value;
  updateAttendanceStats(); renderDashboard();
});
$("#attendanceBulk").addEventListener("change",event=>{
  const status=event.target.value;
  if(!status) return;
  const q=$("#attendanceSearch").value.trim().toLowerCase();
  employees.filter(e=>[e.name,e.id,e.role,e.department,e.email].some(v=>v.toLowerCase().includes(q))).forEach(e=>{getDayAttendance()[e.id]=status;});
  event.target.value=""; renderAttendance(); renderDashboard(); showToast(`Attendance marked: ${status}. Click Save attendance to keep it.`);
});
$("#saveAttendance").addEventListener("click",()=>{saveAttendanceData();renderAttendance();renderDashboard();showToast("Attendance saved successfully.");});
$("#exportPayroll").addEventListener("click",exportPayroll);
$("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#notificationBtn").addEventListener("click",()=>showToast("You're all caught up!"));
$("#todayDate").textContent=new Date().toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"});
$("#footerYear").textContent=new Date().getFullYear();
$("#attendanceDate").value=activeDate;
renderAll();
